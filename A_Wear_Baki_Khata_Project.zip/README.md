# A Wear — Baki Khata (Android starter project)

A simple Bengali/English customer ledger app for a small three-piece clothing business.

## Implemented
- Opens directly to the customer list (no app password/login).
- Saves customer records and transactions locally with Room, so core ledger data works offline.
- Add customer, optional phone and notes.
- Add due amount, record partial payments, and calculate remaining balance from transaction history.
- Search customer and view transaction history.
- Shows total outstanding due.

## Important: Google Drive sync is NOT yet connected
This project is an Android source-code starter, not a finished APK. The “Backup” button currently explains that Drive setup is required; it does not upload or restore data yet. Do not rely on it as a backup until Drive integration has been implemented and tested.

To enable Drive backup/restore:
1. Create a Google Cloud project and enable Google Drive API.
2. Configure Android OAuth consent and an OAuth client for the final application ID `com.awear.bakikhata` and your signing certificate.
3. Add Google Identity / authorization and Drive API dependencies.
4. Implement export/import of customers + transactions as a versioned JSON file in the app's private Drive `appDataFolder`, and test conflict handling and restore on a second device.
5. Use the same Google account on the new phone, authorize once, and restore the backup.
6. Add a clear “Last backup” status and never overwrite local data during restore without confirmation.

## Build APK
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then select:
**Build > Build Bundle(s) / APK(s) > Build APK(s)**

The debug APK is typically produced at:
`app/build/outputs/apk/debug/app-debug.apk`

A local Android SDK and JDK 17 are needed to build. The APK has not been compiled or device-tested in this environment.

## Currency handling
Amounts are stored as integer minor units in the transaction table; for a production release, change the app to consistently use paisa (multiply all displayed BDT amounts by 100) or integer whole taka. The current starter treats amounts entered as taka and stores the amount in paisa for regular transactions, but the opening-due flow needs the same conversion normalization before production use. Review and correct this before real business use.
