package com.awear.bakikhata

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val dao by lazy { LedgerDatabase.get(this).dao() }
    private val money = NumberFormat.getNumberInstance(Locale("en", "BD"))
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private var currentBalances: List<CustomerBalance> = emptyList()
    private var searchText = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        lifecycleScope.launch {
            dao.watchBalances().collect { balances ->
                currentBalances = balances
                renderCustomers()
            }
        }
    }

    private fun buildScreen() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            setBackgroundColor(0xFFF7F8FA.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(12))
        }
        header.addView(TextView(this).apply {
            text = "A Wear"
            textSize = 28f
            setTextColor(0xFF075E54.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        header.addView(TextView(this).apply {
            text = "বাকি খাতা  •  Customer Ledger"
            textSize = 15f
            setTextColor(0xFF52616B.toInt())
        })
        root.addView(header)

        val totals = TextView(this).apply {
            text = "মোট বাকি / Total Due: হিসাব হচ্ছে…"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(0xFF075E54.toInt())
        }
        root.addView(totals)
        lifecycleScope.launch {
            dao.watchTotalBalance().collect { total ->
                totals.text = "মোট বাকি / Total Due: ৳${money.format((total ?: 0) / 100.0)}"
            }
        }

        val search = EditText(this).apply {
            hint = "কাস্টমারের নাম খুঁজুন / Search customer"
            singleLine = true
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        root.addView(search)
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchText = s?.toString().orEmpty()
                renderCustomers()
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(actionButton("＋ নতুন কাস্টমার", "Add customer") { addCustomerDialog() }, weightParams())
        buttons.addView(actionButton("↻ ব্যাকআপ", "Backup") { backupInfoDialog() }, weightParams())
        root.addView(buttons)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun renderCustomers() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val shown = currentBalances.filter { it.name.contains(searchText, ignoreCase = true) }
        if (shown.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (searchText.isBlank()) "এখনো কাস্টমার যোগ করা হয়নি।\nNo customers yet. Tap “নতুন কাস্টমার” to start."
                else "কোনো কাস্টমার পাওয়া যায়নি / No customer found"
                textSize = 16f
                setPadding(dp(12), dp(24), dp(12), dp(24))
            })
        }
        shown.forEach { customer ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setBackgroundColor(0xFFFFFFFF.toInt())
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, dp(5), 0, dp(5))
                layoutParams = lp
            }
            card.addView(TextView(this).apply {
                text = customer.name
                textSize = 18f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(0xFF24323A.toInt())
            })
            if (customer.phone.isNotBlank()) card.addView(TextView(this).apply { text = customer.phone })
            card.addView(TextView(this).apply {
                text = "বাকি / Due: ৳${money.format(customer.balance / 100.0)}"
                textSize = 16f
                setTextColor(if (customer.balance > 0) 0xFFD32F2F.toInt() else 0xFF16834A.toInt())
            })
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(actionButton("＋ বাকি যোগ", "Add due") { amountDialog(customer, "CHARGE") }, weightParams())
            actions.addView(actionButton("৳ টাকা জমা", "Payment") { amountDialog(customer, "PAYMENT") }, weightParams())
            actions.addView(actionButton("ইতিহাস", "History") { historyDialog(customer) }, weightParams())
            card.addView(actions)
            list.addView(card)
        }
    }

    private fun addCustomerDialog() {
        val name = EditText(this).apply { hint = "কাস্টমারের নাম / Customer name" }
        val phone = EditText(this).apply {
            hint = "ফোন নম্বর (ঐচ্ছিক) / Phone (optional)"
            inputType = InputType.TYPE_CLASS_PHONE
        }
        val note = EditText(this).apply { hint = "নোট (ঐচ্ছিক) / Note (optional)" }
        val layout = dialogLayout(name, phone, note)
        AlertDialog.Builder(this).setTitle("নতুন কাস্টমার / New customer")
            .setView(layout)
            .setNegativeButton("বাতিল / Cancel", null)
            .setPositiveButton("সেভ / Save") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isNotBlank()) lifecycleScope.launch {
                    val id = dao.addCustomer(Customer(name = n, phone = phone.text.toString().trim(), note = note.text.toString().trim()))
                    // Optional opening due amount
                    openingDueDialog(id, n)
                } else toast("নাম লিখুন / Enter a name")
            }.show()
    }

    private fun openingDueDialog(customerId: Long, name: String) {
        val amount = EditText(this).apply {
            hint = "শুরুর বাকি টাকা / Opening due (৳)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        AlertDialog.Builder(this).setTitle("$name — শুরুর বাকি")
            .setMessage("এখন বাকি না থাকলে 0 লিখুন বা বাতিল করুন।")
            .setView(amount)
            .setNegativeButton("এখন নয় / Skip", null)
            .setPositiveButton("সেভ / Save") { _, _ ->
                val value = amount.text.toString().toDoubleOrNull()
                if (value != null && value > 0) lifecycleScope.launch {
                    dao.addTransaction(LedgerTransaction(customerId = customerId, type = "CHARGE", amount = (value * 100).toLong()))
                }
            }.show()
    }

    private fun amountDialog(customer: CustomerBalance, type: String) {
        val amount = EditText(this).apply {
            hint = "টাকার পরিমাণ / Amount (৳)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val note = EditText(this).apply { hint = "নোট (ঐচ্ছিক) / Note (optional)" }
        val title = if (type == "PAYMENT") "টাকা জমা / Record payment" else "বাকি যোগ / Add due"
        AlertDialog.Builder(this).setTitle("${customer.name} — $title")
            .setView(dialogLayout(amount, note))
            .setNegativeButton("বাতিল / Cancel", null)
            .setPositiveButton("সেভ / Save") { _, _ ->
                val value = amount.text.toString().toDoubleOrNull()
                if (value == null || value <= 0) {
                    toast("সঠিক টাকার পরিমাণ লিখুন / Enter a valid amount")
                } else if (type == "PAYMENT" && value * 100 > customer.balance) {
                    AlertDialog.Builder(this).setMessage("জমার টাকা বর্তমান বাকি থেকে বেশি। তবুও সেভ করবেন?")
                        .setNegativeButton("না", null)
                        .setPositiveButton("হ্যাঁ") { _, _ -> saveTransaction(customer.id, type, value, note.text.toString()) }.show()
                } else saveTransaction(customer.id, type, value, note.text.toString())
            }.show()
    }

    private fun saveTransaction(id: Long, type: String, value: Double, note: String) {
        lifecycleScope.launch {
            dao.addTransaction(LedgerTransaction(customerId = id, type = type, amount = (value * 100).toLong(), note = note.trim()))
        }
    }

    private fun historyDialog(customer: CustomerBalance) {
        lifecycleScope.launch {
            val transactions = dao.watchTransactions(customer.id)
            transactions.collect { rows ->
                val text = if (rows.isEmpty()) "কোনো লেনদেন নেই / No transactions yet"
                else rows.joinToString("\n\n") {
                    val label = if (it.type == "PAYMENT") "জমা / Payment" else "বাকি যোগ / Due added"
                    val date = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(it.createdAt))
                    "$label: ৳${money.format(it.amount / 100.0)}\n$date${if (it.note.isNotBlank()) "\n${it.note}" else ""}"
                }
                runOnUiThread {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("${customer.name} — লেনদেনের ইতিহাস")
                        .setMessage(text)
                        .setPositiveButton("বন্ধ / Close", null)
                        .show()
                }
                // Render once and stop collection
                break
            }
        }
    }

    private fun backupInfoDialog() {
        AlertDialog.Builder(this)
            .setTitle("Google Drive Backup")
            .setMessage(
                "এই প্রাথমিক সংস্করণে হিসাব ফোনে অফলাইনে সেভ হয়।\n\n" +
                "Google Drive backup/sync চালু করতে Google Cloud Console-এ OAuth configuration এবং Drive API setup করতে হবে। " +
                "এই প্রজেক্টে সেই সংযোগ এখনো যুক্ত করা হয়নি, তাই ব্যাকআপ বোতামটি সেটআপের কথা জানায়—এখনই Drive-এ ফাইল আপলোড করে না।\n\n" +
                "নতুন ফোনে ডেটা ফিরিয়ে আনতে Drive backup feature সম্পূর্ণভাবে সংযুক্ত করা জরুরি।"
            )
            .setPositiveButton("ঠিক আছে / OK", null)
            .show()
    }

    private fun actionButton(bn: String, en: String, action: () -> Unit): Button =
        Button(this).apply {
            text = bn
            textSize = 12f
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun dialogLayout(vararg views: View): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
            views.forEach { addView(it) }
        }

    private fun weightParams() = LinearLayout.LayoutParams(0, -2, 1f)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
