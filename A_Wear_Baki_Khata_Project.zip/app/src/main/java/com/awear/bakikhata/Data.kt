package com.awear.bakikhata

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "transactions",
    foreignKeys = [ForeignKey(
        entity = Customer::class,
        parentColumns = ["id"],
        childColumns = ["customerId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("customerId")]
)
data class LedgerTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    // CHARGE adds to the amount owed; PAYMENT reduces it.
    val type: String,
    val amount: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class CustomerBalance(
    val id: Long,
    val name: String,
    val phone: String,
    val note: String,
    val balance: Long
)

@Dao
interface LedgerDao {
    @Insert suspend fun addCustomer(customer: Customer): Long
    @Insert suspend fun addTransaction(transaction: LedgerTransaction)
    @Query("SELECT c.id, c.name, c.phone, c.note, COALESCE(SUM(CASE WHEN t.type = 'CHARGE' THEN t.amount WHEN t.type = 'PAYMENT' THEN -t.amount ELSE 0 END), 0) AS balance FROM customers c LEFT JOIN transactions t ON t.customerId = c.id GROUP BY c.id ORDER BY c.name COLLATE NOCASE")
    fun watchBalances(): Flow<List<CustomerBalance>>
    @Query("SELECT * FROM customers WHERE id = :customerId LIMIT 1")
    suspend fun getCustomer(customerId: Long): Customer?
    @Query("SELECT * FROM transactions WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun watchTransactions(customerId: Long): Flow<List<LedgerTransaction>>
    @Query("SELECT COALESCE(SUM(CASE WHEN type = 'CHARGE' THEN amount WHEN type = 'PAYMENT' THEN -amount ELSE 0 END), 0) FROM transactions")
    fun watchTotalBalance(): Flow<Long?>
    @Query("SELECT COALESCE(SUM(CASE WHEN type = 'PAYMENT' THEN amount ELSE 0 END), 0) FROM transactions")
    fun watchTotalPayments(): Flow<Long?>
    @Query("SELECT COUNT(*) FROM customers")
    fun watchCustomerCount(): Flow<Int>
    @Query("SELECT * FROM customers ORDER BY id")
    suspend fun allCustomers(): List<Customer>
    @Query("SELECT * FROM transactions ORDER BY id")
    suspend fun allTransactions(): List<LedgerTransaction>
    @Query("DELETE FROM transactions")
    suspend fun clearTransactions()
    @Query("DELETE FROM customers")
    suspend fun clearCustomers()
    @Transaction
    suspend fun replaceAll(customers: List<Customer>, transactions: List<LedgerTransaction>) {
        clearTransactions()
        clearCustomers()
        customers.forEach { addCustomer(it) }
        transactions.forEach { addTransaction(it) }
    }
}

@Database(entities = [Customer::class, LedgerTransaction::class], version = 1, exportSchema = false)
abstract class LedgerDatabase : RoomDatabase() {
    abstract fun dao(): LedgerDao
    companion object {
        @Volatile private var INSTANCE: LedgerDatabase? = null
        fun get(context: Context): LedgerDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, LedgerDatabase::class.java, "awear-ledger.db"
            ).build().also { INSTANCE = it }
        }
    }
}
